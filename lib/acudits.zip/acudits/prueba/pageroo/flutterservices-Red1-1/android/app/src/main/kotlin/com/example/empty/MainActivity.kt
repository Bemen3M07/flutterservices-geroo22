package com.example.empty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
